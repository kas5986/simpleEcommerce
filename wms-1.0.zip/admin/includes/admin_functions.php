<?php 

// all pagination functions can be found in below included file!
require_once("pagination.php");

// all subject functions can be found in below included file!
require_once("subject_functions.php");

// all page functions can be found in below included file!
require_once("page_functions.php");

// all product functions can be found in below included file!
require_once("product_functions.php");

// all users functions can be found in below included file!
require_once("user_functions.php");

// all order functions can be found in below included file!
require_once("order_functions.php");





?>
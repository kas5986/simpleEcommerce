<aside class="col-lg-3">
			

<div class="panel">

	
		<ul class="nav nav-pills nav-stacked">

			<li><a href="<?php echo site_options('link'); ?>admin/index.php">Dashboard</a></li>
			<li><a href="<?php echo site_options('link'); ?>admin/admin_options.php">General Settings</a></li>
			<li><a href="<?php echo site_options('link'); ?>admin/order_index.php">Orders</a></li>
			<li><a href="<?php echo site_options('link'); ?>admin/subject_index.php">Subjects</a></li>
			<li><a href="<?php echo site_options('link'); ?>admin/page_index.php">Pages</a></li>
			<li><a href="<?php echo site_options('link'); ?>admin/products_index.php">Products</a></li>
			<li><a href="<?php echo site_options('link'); ?>admin/users_index.php">Users</a></li>

			
		</ul>
		
</div>

			
			
</aside>
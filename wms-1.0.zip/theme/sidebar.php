<aside class="col-lg-3">

		<ul class="nav nav-pills nav-stacked">

			<?php 
			
				get_navigation(1, 'sidebar');
			?>

		</ul>
		
			
</aside>
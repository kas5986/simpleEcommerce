<?php 

	header("Location: content.php");
	exit;

?>
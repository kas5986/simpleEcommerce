<?php 
	
// Database configration
define('DB_SERVER', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'w-sell');


// google reCaptcha keys
define('CAPTCHA_PUBLIC', '6Lc77OsSAAAAAHcmih7nq3CYRc2inXLK1BrzTROv');
define('CAPTCHA_PRIVATE', '6Lc77OsSAAAAAJj3ioJ5Yv4LlXQH8BPi0Rz32tGk');


?>